
#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include<unistd.h>
#include "SAT.h"
#include "func.h"


#include <pthread.h>
#include <time.h>

struct adjMatrix{
		int vertex;
		int **matrix;
	};

int *cnf_verIndex;
int *approx1_verIndex;
int *approx2_verIndex;
int cnf_cnt = -1;
int approx1_cnt = -1;
int approx2_cnt = -1;

clockid_t cid1;
clockid_t cid2;
clockid_t cid3;

struct timespec ts1;
struct timespec ts2;
struct timespec ts3;


void printVC(char *name, int nameCount, int *verIndex, int cnt){
		int i;
		for(i = 0; i < nameCount; i++){
			printf("%c", name[i]);
			fflush(stdout);
		}
		printf(" ");
		fflush(stdout);
		if(cnt != -1){
			cnt++;
			for(i = 0; i < cnt - 1; i++){
				printf("%d,", verIndex[i]);
				fflush(stdout);
			}
			printf("%d\n", verIndex[cnt - 1]);
			fflush(stdout);
		}
		else{
			printf("\n");
			fflush(stdout);
		}

};

void* approx1(void *adjMat){
			struct adjMatrix* mat;
                        mat = (struct adjMatrix*)(adjMat);
			int i;
			int j;
			approx1_verIndex = (int *)malloc(mat->vertex * sizeof(int));
			int **copyMat = (int **)malloc(mat->vertex * sizeof(int*));
                        for (i = 0; i < mat->vertex; i++)
                                copyMat[i] = (int *)malloc(mat->vertex * sizeof(int));

			for(i = 0; i < mat->vertex; i++){
				for(j = 0; j < mat->vertex; j++){
					copyMat[i][j] = mat->matrix[i][j];
				}
			}
			int highestDegree;
			int highestVertex;
			int sum;


			do{
				highestDegree = 0;
				highestVertex = 0;
				for(i = 0; i < mat->vertex; i++){
					sum = 0;
					for(j = 0; j < mat->vertex; j++){
						sum += copyMat[i][j];
					}
					sum -= 1;
					if(sum >= highestDegree){
						highestVertex = i;
						highestDegree = sum;
					}
				}

				if(highestDegree != 0){
					approx1_cnt++;
					approx1_verIndex[approx1_cnt] = highestVertex;
					for(i = 0; i < mat->vertex; i++){
						copyMat[highestVertex][i] = 0;
						copyMat[i][highestVertex] = 0;
					}

				}
			}while(highestDegree != 0);


			for(i = 0; i < mat->vertex; i++)
				free(copyMat[i]);
			free(copyMat);

			int s;
			qsort(approx1_verIndex, approx1_cnt + 1, sizeof(int), comparison);
                        s = pthread_getcpuclockid(pthread_self(), &cid2);
			clock_gettime(cid2, &ts2);
};

void* approx2(void* adjMat){
			struct adjMatrix* mat;
			mat = (struct adjMatrix*)(adjMat);
			int i;
			int j;
                        approx2_verIndex = (int *)malloc(mat->vertex * sizeof(int));
                        int **copyMat = (int **)malloc(mat->vertex * sizeof(int*));
                        for (i = 0; i < mat->vertex; i++)
                                copyMat[i] = (int *)malloc(mat->vertex * sizeof(int));

                        for(i = 0; i < mat->vertex; i++){
                                for(j = 0; j < mat->vertex; j++){
                                        copyMat[i][j] = mat->matrix[i][j];
                                }
                        }

			int k;

			for(i = 0; i < mat->vertex; i++){
				for(j = 0; j < mat->vertex; j++){
					if(copyMat[i][j] == 1 && i != j){
						approx2_cnt++;
						approx2_verIndex[approx2_cnt] = i;
						approx2_cnt++;
						approx2_verIndex[approx2_cnt] = j;
						for(k = 0; k < mat->vertex; k++){
							copyMat[i][k] = 0;
							copyMat[k][i] = 0;
							copyMat[j][k] = 0;
							copyMat[k][j] = 0;
						}
					}
				}
			}

                        for(i = 0; i < mat->vertex; i++)
                                free(copyMat[i]);
                        free(copyMat);

			int s;
			qsort(approx2_verIndex, approx2_cnt + 1, sizeof(int), comparison);
                        s = pthread_getcpuclockid(pthread_self(), &cid3);
                        clock_gettime(cid3, &ts3);

};


void* cnfSat(void *adjMat){
			struct adjMatrix* mat;
                        mat = (struct adjMatrix*)(adjMat);
			int i;
			int n = mat->vertex;
			int k = 1;

    			while(k <= n){
				int fd[2];
				int tmp;
				pipe(fd);
				tmp = dup(STDOUT_FILENO);
				dup2(fd[1], STDOUT_FILENO);


				int varNum = n * k;
				int j;
				int m;
				int p;
				int q;
				int edgeNum = 0;
				for(i = 0; i < mat->vertex; i++){
					for(j = 0; j < mat->vertex; j++){
						if(i != j && mat->matrix[i][j] == 1)
							edgeNum++;
					}
				}

				edgeNum = edgeNum / 2;

				int clauseNum = k + n * combination(k,2) + k * combination(n,2) + edgeNum;

				SAT_Manager mgr = SAT_InitManager();
				SAT_SetNumVariables(mgr, varNum);
				int c[clauseNum];

				char index[2];
				int indexNum1;
				int indexNum2;

				for(i = 1; i <= k; i++){
					for(j = 1; j <= n; j++){
						indexNum1 = j + (i-1)*n;
						c[j-1] = (indexNum1 << 1);
					}
					SAT_AddClause(mgr, c, n);
				}
				for(m = 1; m <= n; m++){
					for(p = 1; p <= k; p++){
						for(q = p + 1; q <= k; q++){
							indexNum1 = m + (p-1)*n;
							indexNum2 = m + (q-1)*n;
							c[0] = (indexNum1 << 1) + 1;
							c[1] = (indexNum2 << 1) + 1;
							SAT_AddClause(mgr, c, 2);
						}
					}
				}

				for(m = 1; m <= k; m++){
					for(p = 1; p <= n; p++){
						for(q = p + 1; q <= n ; q++){
							indexNum1 = p + (m-1)*n;
							indexNum2 = q + (m-1)*n;
							c[0] = (indexNum1 << 1) + 1;
							c[1] = (indexNum2 << 1) + 1;
							SAT_AddClause(mgr, c, 2);
						}
					}
				}

				int cnt;
				for(i = 0; i < mat->vertex; i++){
					for(j = i + 1; j < mat->vertex; j++){
						cnt = 0;
						if( mat->matrix[i][j] == 1){
							for(m = 1; m <= k; m++){
								indexNum1 = (i+1) + (m-1)*n;
								indexNum2 = (j+1) + (m-1)*n;
								c[cnt] = (indexNum1 << 1);
								cnt++;
								c[cnt] = (indexNum2 << 1);
								cnt++;
							}
							SAT_AddClause(mgr, c, 2*k);
						}
					}
				}

				int result = SAT_Solve(mgr);
				dup2(tmp, STDOUT_FILENO);
				if(result == SATISFIABLE){
					int varNum = SAT_NumVariables(mgr);
					cnf_verIndex = (int *)malloc(n * sizeof(int));

					for(i = 1; i <= varNum; i++){
						int varAssign = SAT_GetVarAsgnment(mgr, i);
						if( varAssign == 1){
							if(i > n){
								if((i % n) == 0){
									cnf_cnt++;
									cnf_verIndex[cnf_cnt] = n - 1;
								}
								else{
									cnf_cnt++;
									cnf_verIndex[cnf_cnt] = (i % n) - 1;
								}
							}
							else{
								cnf_cnt++;
								cnf_verIndex[cnf_cnt] = i - 1;
							}
						}
					}


					if(edgeNum == 0)
						cnf_cnt = -1;
					break;

				}
				else{
					k++;
					SAT_Reset(mgr);
				}

    			}

			int s;
			qsort(cnf_verIndex, cnf_cnt + 1, sizeof(int), comparison);
                        s = pthread_getcpuclockid(pthread_self(), &cid1);
                        clock_gettime(cid1, &ts1);

};


int main(int argc, char *argv[]){

	struct adjMatrix mat;

	pthread_t cnf_sat_vc_thread;
	pthread_t approx_vc_1_thread;
	pthread_t approx_vc_2_thread;

	mat.vertex = -1;
	char tmp;
	int flag = 0;
	int len;
	char *text;
	char *tmptext;
	int count;
	int freeMatrix = 0;

	while ((tmp = getchar()) != EOF){

		cnf_cnt = -1;
		approx1_cnt = -1;
		approx2_cnt = -1;
  		//Get input, Store in text
  		len = 1000;
  		text = (char *)malloc(len * sizeof(char));
		if(!text){
			fprintf(stderr, "Error: The input size is too large.\n");
			flag = 0;
			mat.vertex = -1;
			continue;
		}
  		count = 0;
  		text[count] = tmp;
  		count++;
		text[count] = '\0';
  		while ((tmp = getchar()) != '\n'){
       			if (count+1 >= len){
          			tmptext = (char *)realloc(text, (len += 100) * sizeof(*tmptext));
				if(!tmptext){
					fprintf(stderr, "Error: The input size is too large.\n");
					flag = 0;
					mat.vertex = -1;
					free(text);
					break;
				}
				text = tmptext;
			}
       			text[count] = tmp;
       			count++;
       			text[count] = '\0';
  		}
		if(!text){
			if(freeMatrix == 1){
				int z;
                		for(z = 0; z < mat.vertex; z++)
                        		free(mat.matrix[z]);
                		free(mat.matrix);
			}
			continue;
		}
  		//V command
  		if(text[0] == 'V'){
  			int vcheck = extractVertexNumber(text, count);
			if(flag == 2){
				//Free matrix
				if(freeMatrix == 1){
					int i;
					for(i = 0; i < mat.vertex; i++)
						free(mat.matrix[i]);
					free(mat.matrix);
					freeMatrix = 0;
				}
			}
			if(vcheck < 0){
                                fprintf(stderr, "Error: Set of vertices can not be negative.\n");
                                flag = 0;
                                mat.vertex = -1;
                                free(text);
				continue;
                        }
			mat.vertex = vcheck;
			flag = 1;
			free(text);
  		}

  		//E command
  		else if(text[0] == 'E'){
			if(flag == 0 || flag == 2){
				fprintf(stderr, "Error: 'V' has to  be entered before 'E'.\n");
				free(text);
				flag = 0;
				mat.vertex = -1;
				continue;
			}
			int err;
			//Matrix allocation
			mat.matrix = (int **)malloc(mat.vertex * sizeof(int*));
        		int i;
        		for (i = 0; i < mat.vertex; i++)
        			mat.matrix[i] = (int *)malloc(mat.vertex * sizeof(int));
			freeMatrix = 1;
			if(mat.vertex == 0)
				freeMatrix = 0;
			//Create the adjacency matrix
  			err = createMatrix(text, count, mat.vertex, mat.matrix);
			if(err == 1){
				free(text);
				//free matrix
				if(freeMatrix == 1){
					int j;
                			for(j = 0; j < mat.vertex; j++)
                      				free(mat.matrix[j]);
                			free(mat.matrix);
					freeMatrix = 0;
				}
				flag = 0;
				mat.vertex = -1;
				continue;
			}
			else{
				flag = 2;
				free(text);
  			}

			


			 char cnf_string[11];
                                cnf_string[0] = 'C';
                                cnf_string[1] = 'N';
                                cnf_string[2] = 'F';
                                cnf_string[3] = '-';
                                cnf_string[4] = 'S';
                                cnf_string[5] = 'A';
                                cnf_string[6] = 'T';
                                cnf_string[7] = '-';
                                cnf_string[8] = 'V';
                                cnf_string[9] = 'C';
                                cnf_string[10] = ':';

                                char aprx_string[12];
                                aprx_string[0] = 'A';
                                aprx_string[1] = 'P';
                                aprx_string[2] = 'P';
                                aprx_string[3] = 'R';
                                aprx_string[4] = 'O';
                                aprx_string[5] = 'X';
                                aprx_string[6] = '-';
                                aprx_string[7] = 'V';
                                aprx_string[8] = 'C';
                                aprx_string[9] = '-';
                                aprx_string[10] = '1';
                                aprx_string[11] = ':';

				if(argc == 1 || (argc == 2 && strcmp(argv[1], "time") && mat.vertex <= 15) || (argc == 2 && strcmp(argv[1], "ratio") && mat.vertex <= 15)){
					int p1 = pthread_create(&cnf_sat_vc_thread, NULL, &cnfSat, (void *)(&mat));
					int p2 = pthread_create(&approx_vc_1_thread, NULL, &approx1, (void *)(&mat));
					int p3 = pthread_create(&approx_vc_2_thread, NULL, &approx2, (void*)(&mat));


					pthread_join(cnf_sat_vc_thread, NULL);
					pthread_join(approx_vc_1_thread, NULL);
					pthread_join(approx_vc_2_thread, NULL);
				}
				else{
					int p2 = pthread_create(&approx_vc_1_thread, NULL, &approx1, (void *)(&mat));
                                        int p3 = pthread_create(&approx_vc_2_thread, NULL, &approx2, (void*)(&mat));

					pthread_join(approx_vc_1_thread, NULL);
                                        pthread_join(approx_vc_2_thread, NULL);

				}

				if(argc == 1){
					printVC(cnf_string, 11, cnf_verIndex, cnf_cnt);
					printVC(aprx_string, 12, approx1_verIndex, approx1_cnt);
					aprx_string[10] = '2';
					printVC(aprx_string, 12, approx2_verIndex, approx2_cnt);
				}

				else if(argc == 2 && strcmp(argv[1], "ratio") == 0){
					if(mat.vertex <= 15)
						 printVC(cnf_string, 11, cnf_verIndex, cnf_cnt);
					printVC(aprx_string, 12, approx1_verIndex, approx1_cnt);
                                        aprx_string[10] = '2';
                                        printVC(aprx_string, 12, approx2_verIndex, approx2_cnt);

				}

				else if(argc == 2 && strcmp(argv[1], "time") == 0){
					if(mat.vertex <= 15){
						printf("CNF-SAT-VC: %ld.%09ld\n", ts1.tv_sec, ts1.tv_nsec);
						fflush(stdout);
					}
					printf("APPROX-VC-1: %ld.%09ld\n", ts2.tv_sec, ts2.tv_nsec);
					fflush(stdout);
					printf("APPROX-VC-2: %ld.%09ld\n", ts3.tv_sec, ts3.tv_nsec);
					fflush(stdout);
				}
				if(mat.vertex != 0){
					free(cnf_verIndex);
					free(approx1_verIndex);
					free(approx2_verIndex);
				}


		}

	}

	if(freeMatrix == 1){
                int p;
                for(p = 0; p < mat.vertex; p++)
                       	free(mat.matrix[p]);
      		free(mat.matrix);
   	}

	return 0;

};
