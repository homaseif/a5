#!/usr/bin/python

import sys
import math

cnfMean = []
approx1Mean = []
approx2Mean = []

cnfStdv = []
approx1Stdv = []
approx2Stdv = []

cnfTime = []
approx1Time = []
approx2Time = []

def findMean(l):
	sum = 0
	for elem in l:
		sum = sum + elem
	mean = sum / len(l)
	return mean

def findStdv(l):
	mean = findMean(l)
	sum = 0
	for elem in l:
		elem = (elem - mean)**2
		sum = sum + elem
	tmp = sum / len(l)
	stdv = math.sqrt(tmp)
	return stdv

line = sys.stdin.readline()

while True:

		line = sys.stdin.readline()
		if len(line) <= 0:
			if len(cnfTime) != 0:
				cnfMean.append(findMean(cnfTime))
                        	cnfStdv.append(findStdv(cnfTime))
                        approx1Mean.append(findMean(approx1Time))
                        approx1Stdv.append(findStdv(approx1Time))
                        approx2Mean.append(findMean(approx2Time))
                        approx2Stdv.append(findStdv(approx2Time))
			break


		if line[0] == '1' or line[0] == '2' or line[0] == '3' or line[0] == '4' or line[0] == '5':
			if len(cnfTime) != 0:
				cnfMean.append(findMean(cnfTime))
				cnfStdv.append(findStdv(cnfTime))
			approx1Mean.append(findMean(approx1Time))
			approx1Stdv.append(findStdv(approx1Time))
			approx2Mean.append(findMean(approx2Time))
			approx2Stdv.append(findStdv(approx2Time))
			del cnfTime[:]
			del approx1Time[:]
			del approx2Time[:]
		
		elif line[0] == 'C':
			tmp = line.split(':')
			cnfTime.append(float(tmp[1].strip()))
		elif line[10] == '1':
			tmp = line.split(':')
			approx1Time.append(float(tmp[1].strip()))
		elif line[10] == '2':
			tmp = line.split(':')
			approx2Time.append(float(tmp[1].strip()))



f = open('cnfTime', 'w')
ver = 5
stdv = 0
for i in cnfMean:
	f.write(str(ver))
	f.write("  ")
	f.write(str(i))
	f.write("  ")
	f.write(str(cnfStdv[stdv]))
	f.write("\n")
	ver = ver + 5
	stdv = stdv + 1
f.close()

f = open('approx1Time', 'w')
ver = 5
stdv = 0
for i in approx1Mean:
        f.write(str(ver))
        f.write("  ")
        f.write(str(i*1000000))
        f.write("  ")
        f.write(str(approx1Stdv[stdv]*1000000))
        f.write("\n")
        ver = ver + 5
        stdv = stdv + 1
f.close()

f = open('approx2Time', 'w')
ver = 5
stdv = 0
for i in approx2Mean:
        f.write(str(ver))
        f.write("  ")
        f.write(str(i*1000000))
        f.write("  ")
        f.write(str(approx2Stdv[stdv]*1000000))
        f.write("\n")
        ver = ver + 5
        stdv = stdv + 1
f.close()


