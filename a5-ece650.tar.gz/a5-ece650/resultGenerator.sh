#!/bin/bash

#change the location of graphGen on ecelinux

vertexNum=5
while [ $vertexNum -lt 51 ]; do
	echo $vertexNum >> approxRatio
	echo $vertexNum >> timeMeasure
	for i in 0 1 2 3 4 5 6 7 8 9
	do
		./home/wdietl/graphGen/graphGen $vertexNum > graphOut
		cat graphOut | ./a5-ece650 ratio >> approxRatio
		for i in 0 1 2 3 4 5 6 7 8 9
		do
			cat graphOut | ./a5-ece650 time >> timeMeasure
		done
	done
	let vertexNum=vertexNum+5
done

chmod u+x timeAnalysis.py
cat timeMeasure | ./timeAnalysis.py
chmod u+x ratioAnalysis.py
cat approxRatio | ./ratioAnalysis.py

#gnuplot
gnuplot <<EOF
set terminal postscript eps color enhanced
set output 'timeAnalysisCNF.pdf'
set key inside left top vertical Right noreverse enhanced autotitles box linetype -1 linewidth 1.000
set samples 300, 300
set title "CNF-SAT Time Analysis"
set xrange [0:55]
set xtics 5
set xlabel "Number of Vertices"
set ylabel "Running Time({/Symbol m}s)"
plot "approx1Time" title "approx-1" with yerrorlines, "approx2Time" title "Approx-2" with yerrorlines
EOF

gnuplot <<EOF
set terminal postscript eps color enhanced
set output 'timeAnalysisApprox.pdf'
set key inside left top vertical Right noreverse enhanced autotitles box linetype -1 linewidth 1.000
set samples 300, 300
set title "Approximation Time Analysis"
set xrange [0:25]
set xtics 5
set xlabel "Number of Vertices"
set ylabel "Running Time({/Symbol m}s)"
plot "cnfTime" title "CNF-SAT" with yerrorlines
EOF

gnuplot <<EOF
set terminal postscript eps color enhanced
set output 'ratioAnalysis.pdf'
set key inside left top vertical Right noreverse enhanced autotitles box linetype -1 linewidth 1.000
set samples 300, 300
set title "Ratio Analysis"
set xrange [0:55]
set xtics 5
set xlabel "Number of Vertices"
set ylabel "Approximation Ratio"
plot "cnfRatio" title "CNF-SAT" with yerrorlines, "approx1Ratio" title "Approx-1" with yerrorlines, "approx2Ratio" title "Approx-2" with yerrorlines
EOF
