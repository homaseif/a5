int createMatrix(char *txt, int size, int vertex, int **mat);
int extractVertexNumber(char *txt, int size);
int combination(int n, int m);
int comparison(const void *a, const void *b);
