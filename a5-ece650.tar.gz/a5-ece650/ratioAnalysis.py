#!/usr/bin/python

import sys
import math

cnfMean = []
approx1Mean = []
approx2Mean = []

cnfStdv = []
approx1Stdv = []
approx2Stdv = []

cnfRatio = []
approx1Ratio = []
approx2Ratio = []


def findMean(l):
	sum = 0
	for elem in l:
		sum = sum + elem
	mean = sum / len(l)
	return mean

def findStdv(l):
	mean = findMean(l)
	sum = 0
	for elem in l:
		elem = (elem - mean)**2
		sum = sum + elem
	tmp = sum / len(l)
	stdv = math.sqrt(tmp)
	return stdv

def sizeOfVerCover(l):
	tmp = l.split(':')
        tmp[1] = tmp[1].strip()
        verIndex = tmp[1].split(',')
        return len(verIndex)


line = sys.stdin.readline()

while True:

		line = sys.stdin.readline()
		if len(line) <= 0:
			if len(cnfRatio) != 0:
				cnfMean.append(findMean(cnfRatio))
                        	cnfStdv.append(findStdv(cnfRatio))
                        approx1Mean.append(findMean(approx1Ratio))
                        approx1Stdv.append(findStdv(approx1Ratio))
                        approx2Mean.append(findMean(approx2Ratio))
                        approx2Stdv.append(findStdv(approx2Ratio))
			break


		if line[0] == '1' or line[0] == '2' or line[0] == '3' or line[0] == '4' or line[0] == '5':
			if len(cnfRatio) != 0:
				cnfMean.append(findMean(cnfRatio))
				cnfStdv.append(findStdv(cnfRatio))
			approx1Mean.append(findMean(approx1Ratio))
			approx1Stdv.append(findStdv(approx1Ratio))
			approx2Mean.append(findMean(approx2Ratio))
			approx2Stdv.append(findStdv(approx2Ratio))
			del cnfRatio[:]
			del approx1Ratio[:]
			del approx2Ratio[:]
		
		elif line[0] == 'C':
			cnfSize = sizeOfVerCover(line)
			cnfRatio.append(float(cnfSize) / float(cnfSize))
		elif line[10] == '1':
			approx1Size = sizeOfVerCover(line)
			approx1Ratio.append(float(approx1Size) / float(cnfSize))
		elif line[10] == '2':
			approx2Size = sizeOfVerCover(line)
			approx2Ratio.append(float(approx2Size) / float(cnfSize))


f = open('cnfRatio', 'w')
ver = 5
stdv = 0
for i in cnfMean:
	f.write(str(ver))
	f.write("  ")
	f.write(str(i))
	f.write("  ")
	f.write(str(cnfStdv[stdv]))
	f.write("\n")
	ver = ver + 5
	stdv = stdv + 1
f.close()

f = open('approx1Ratio', 'w')
ver = 5
stdv = 0
for i in approx1Mean:
        f.write(str(ver))
        f.write("  ")
        f.write(str(i))
        f.write("  ")
        f.write(str(approx1Stdv[stdv]))
        f.write("\n")
        ver = ver + 5
        stdv = stdv + 1
f.close()

f = open('approx2Ratio', 'w')
ver = 5
stdv = 0
for i in approx2Mean:
        f.write(str(ver))
        f.write("  ")
        f.write(str(i))
        f.write("  ")
        f.write(str(approx2Stdv[stdv]))
        f.write("\n")
        ver = ver + 5
        stdv = stdv + 1
f.close()


