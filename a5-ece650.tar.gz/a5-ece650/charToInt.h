int charToInt (char *number, int count);
